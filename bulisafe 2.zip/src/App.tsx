/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ShieldAlert, 
  HelpCircle, 
  MessageSquare, 
  ShieldCheck, 
  ArrowRight, 
  XCircle, 
  AlertTriangle, 
  Heart, 
  BookOpen,
  LifeBuoy,
  X,
  RefreshCw,
  LogOut,
  ChevronRight,
  EyeOff
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types & Constants ---

type RiskLevel = 'low' | 'medium' | 'high' | null;

interface BullyQuestion {
  id: string;
  category: 'physical' | 'verbal' | 'social' | 'cyber';
  text: string;
  weight: number;
}

const QUESTIONS: BullyQuestion[] = [
  { id: 'p1', category: 'physical', text: 'Pernah dipukul, ditunjal, atau disakiti secara fizikal?', weight: 3 },
  { id: 'p2', category: 'physical', text: 'Barang peribadi dirosakkan atau diambil tanpa izin?', weight: 2 },
  { id: 'v1', category: 'verbal', text: 'Sering dipanggil dengan gelaran yang menghina atau memalukan?', weight: 2 },
  { id: 'v2', category: 'verbal', text: 'Diancam atau diugut akan disakiti?', weight: 3 },
  { id: 's1', category: 'social', text: 'Dipulaukan atau sengaja tidak diajak dalam aktiviti berkumpulan?', weight: 2 },
  { id: 's2', category: 'social', text: 'Fitnah atau khabar angin buruk disebarkan tentang anda?', weight: 2 },
  { id: 'c1', category: 'cyber', text: 'Mesej atau komen menghina diterima di media sosial?', weight: 2 },
  { id: 'c2', category: 'cyber', text: 'Gambar atau maklumat peribadi disebarkan tanpa izin di internet?', weight: 3 },
];

// --- Components ---

const ResultCard = ({ level, onReset }: { level: RiskLevel; onReset: () => void }) => {
  const configs = {
    high: {
      bgColor: 'bg-brand-red',
      textColor: 'text-black',
      icon: <XCircle className="w-12 h-12" />,
      tag: 'STATUS: MERAH (TINGGI)',
      title: 'TINDAKAN SEGERA.',
      desc: 'Keadaan anda serius. Kami mencadangkan langkah drastik untuk keselamatan anda.',
      actions: [
        'Lapor terus kepada Pengetua Sekolah',
        'Maklumkan Ibu Bapa atau penjaga segera',
        'Email KPM: adubuli@moe.gov.my',
        'Talian KPM: 03-8884 9325',
        'Talian Kasih 15999 atau Polis (999)',
        'Simpan bukti (gambar/mesej) secara selamat'
      ]
    },
    medium: {
      bgColor: 'bg-amber-400',
      textColor: 'text-black',
      icon: <AlertTriangle className="w-12 h-12" />,
      tag: 'STATUS: KUNING (SEDERHANA)',
      title: 'DAPATKAN BANTUAN.',
      desc: 'Situasi ini perlu dikawal sebelum ia bertukar menjadi lebih bahaya.',
      actions: [
        'Berjumpa dengan Guru Kaunseling sekolah',
        'Bincangkan dengan Guru Kelas yang dipercayai',
        'Luahkan kepada rakan baik atau keluarga',
        'Dokumenkan setiap kejadian yang berlaku'
      ]
    },
    low: {
      bgColor: 'bg-emerald-400',
      textColor: 'text-black',
      icon: <ShieldCheck className="w-12 h-12" />,
      tag: 'STATUS: HIJAU (RENDAH)',
      title: 'KEKAL BERANI.',
      desc: 'Tindakan ini mungkin diperingkat awal. Anda boleh menghentikannya sekarang.',
      actions: [
        'Gunakan komunikasi asertif (berani kata TIDAK)',
        'Laporkan kepada guru sebagai rekod awal',
        'Cari kumpulan sokongan rakan sebaya',
        'Bina keyakinan diri dan jangan takut'
      ]
    }
  };

  const config = level ? configs[level] : configs.low;

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className={`p-10 rounded-[32px] ${config.bgColor} ${config.textColor} flex flex-col justify-between h-full min-h-[500px] shadow-2xl relative overflow-hidden`}
    >
      <div className="absolute top-0 right-0 p-8 opacity-20">
        {config.icon}
      </div>

      <div>
        <span className="inline-block px-3 py-1 bg-black text-white text-[10px] font-black rounded mb-8 uppercase tracking-widest">
          {config.tag}
        </span>
        <h3 className="text-6xl font-black leading-none mb-6 italic tracking-tighter uppercase">
          {config.title.split(' ').map((word, i) => <React.Fragment key={i}>{word}<br /></React.Fragment>)}
        </h3>
        <p className="text-xl font-bold leading-tight mb-8 max-w-sm">
          {config.desc}
        </p>
        
        <ul className="space-y-4 mb-10">
          {config.actions.map((action, i) => (
            <li key={i} className="flex items-start gap-2 font-black text-sm uppercase tracking-tight">
              <span className="mt-1 flex-shrink-0">•</span>
              <span>{action}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="flex flex-col gap-3">
        <button 
          onClick={() => window.open('https://www.kpwkm.gov.my/', '_blank')}
          className="w-full bg-black text-white py-5 rounded-2xl font-black text-sm uppercase urgent-pulse tracking-widest"
        >
          JANA SURAT LAPORAN RASMI
        </button>
        <button 
          onClick={onReset}
          className="w-full bg-white/20 backdrop-blur-md py-4 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-white/30"
        >
          Mula Semula
        </button>
      </div>
    </motion.div>
  );
};

export default function App() {
  const [view, setView] = useState<'home' | 'test' | 'computing' | 'result' | 'journal'>('home');
  const [answers, setAnswers] = useState<Set<string>>(new Set());
  const [riskLevel, setRiskLevel] = useState<RiskLevel>(null);

  const handleQuickExit = () => {
    window.location.href = "https://www.google.com/search?q=cuaca+hari+ini";
  };

  const startTest = () => {
    setView('test');
    setAnswers(new Set());
  };

  const toggleAnswer = (id: string) => {
    const newAnswers = new Set(answers);
    if (newAnswers.has(id)) newAnswers.delete(id);
    else newAnswers.add(id);
    setAnswers(newAnswers);
  };

  const calculateResult = () => {
    setView('computing');
    
    // Simulate a brief "thinking" state for UX
    setTimeout(() => {
      let score = 0;
      answers.forEach(id => {
        const q = QUESTIONS.find(q => q.id === id);
        if (q) score += q.weight;
      });

      if (score >= 10) setRiskLevel('high');
      else if (score >= 5) setRiskLevel('medium');
      else setRiskLevel('low');
      
      setView('result');
    }, 2000);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 10 },
    show: { opacity: 1, scale: 1, y: 0 }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans selection:bg-brand-red selection:text-white">
      <div className="flex flex-col lg:flex-row h-screen overflow-hidden">
        
        {/* SIDE RAIL */}
        <aside className="w-full lg:w-80 border-b lg:border-b-0 lg:border-r border-zinc-800 p-10 flex flex-col justify-between shrink-0 bg-zinc-950/50 backdrop-blur-xl z-50">
          <div>
            <div className="hero-typography mb-4 cursor-pointer" onClick={() => setView('home')}>
              SUA<br />RA.
            </div>
            <p className="label-typography">Komuniti Bebas Buli</p>

            <nav className="mt-20 space-y-8">
              {[
                { id: 'home', label: 'UTAMA' },
                { id: 'test', label: 'ADUAN' },
                { id: 'journal', label: 'LUAHAN' }
              ].map((item) => (
                <button 
                  key={item.id}
                  onClick={() => setView(item.id as any)}
                  className={`block text-3xl font-black transition-all text-left ${
                    view === item.id || (view === 'result' && item.id === 'test') || view === 'computing' && item.id === 'test'
                      ? 'border-b-8 border-brand-red pb-2 opacity-100' 
                      : 'opacity-20 hover:opacity-40'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="mt-12 space-y-4">
            <div className="bg-zinc-900/80 p-6 rounded-[24px] border border-zinc-800">
              <p className="label-typography text-[9px] mb-2 text-brand-red urgent-pulse">Adu Buli KPM</p>
              <div className="space-y-4">
                <div>
                  <p className="text-[10px] font-black uppercase opacity-40 mb-1">Email</p>
                  <p className="text-sm font-black break-all">adubuli@moe.gov.my</p>
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase opacity-40 mb-1">Telefon</p>
                  <p className="text-xl font-black text-brand-red">03-8884 9325</p>
                </div>
              </div>
            </div>
            
            <div className="bg-zinc-900/40 p-5 rounded-[24px] border border-zinc-800/50">
              <p className="label-typography text-[8px] mb-1 opacity-50">Talian Kasih</p>
              <p className="text-lg font-black leading-tight opacity-70">
                15999
              </p>
            </div>
          </div>
        </aside>

        {/* MAIN CONTENT AREA */}
        <main className="flex-1 overflow-y-auto p-6 md:p-16 relative">
          {/* Quick Actions Header */}
          <div className="fixed top-6 right-6 z-50 flex items-center gap-3">
             <button 
              onClick={handleQuickExit}
              className="bg-zinc-800 hover:bg-zinc-700 text-white px-5 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 border border-zinc-700 shadow-2xl transition-transform active:scale-95"
            >
              <EyeOff className="w-4 h-4" />
              Keluar Segera
            </button>
          </div>

          <AnimatePresence mode="wait">
            {view === 'home' && (
              <motion.div 
                key="home"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
                className="max-w-4xl h-full flex flex-col justify-center"
              >
                <div className="mb-8">
                  <motion.span 
                    initial={{ opacity: 0, x: -10 }} 
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="inline-block px-3 py-1 bg-white text-black text-[10px] font-black rounded mb-6 uppercase tracking-widest"
                  >
                    LANGKAH 01: PENILAIAN KENDIRI
                  </motion.span>
                  <h1 className="text-6xl md:text-[100px] font-black leading-[0.88] mb-10 tracking-tighter uppercase italic">
                    Kenal Pasti<br />Situasi Anda.
                  </h1>
                  <p className="text-2xl font-bold text-slate-400 mb-12 max-w-xl leading-snug">
                    Buli bukan perkara biasa. Platform ini membantu anda mendapatkan suara dan perlindungan yang sewajarnya.
                  </p>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={startTest}
                      className="bg-brand-red text-black px-12 py-6 rounded-[24px] font-black text-xl uppercase tracking-tighter hover:scale-105 transition-all flex items-center gap-4 active:scale-95 shadow-xl shadow-brand-red/10"
                    >
                      MULA PENILAIAN <ArrowRight className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={() => setView('journal')}
                      className="bg-zinc-900 border border-zinc-800 text-white px-12 py-6 rounded-[24px] font-black text-xl uppercase tracking-tighter hover:bg-zinc-800 transition-all active:scale-95"
                    >
                      BILIK LUAHAN
                    </button>
                  </div>
                </div>

                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-16 border-t border-zinc-900"
                >
                  <motion.div variants={itemVariants} className="group">
                    <p className="label-typography mb-2 group-hover:text-brand-red transition-colors">SULIT</p>
                    <p className="text-sm font-bold text-slate-500 uppercase">Data anda tidak akan disimpan di server.</p>
                  </motion.div>
                  <motion.div variants={itemVariants} className="group">
                    <p className="label-typography mb-2 group-hover:text-amber-400 transition-colors">SAHIH</p>
                    <p className="text-sm font-bold text-slate-500 uppercase">Berdasarkan garis panduan kementerian.</p>
                  </motion.div>
                  <motion.div variants={itemVariants} className="group">
                    <p className="label-typography mb-2 group-hover:text-emerald-400 transition-colors">SELAMAT</p>
                    <p className="text-sm font-bold text-slate-500 uppercase">Dilengkapi fungsi keluar segera pantas.</p>
                  </motion.div>
                </motion.div>
              </motion.div>
            )}

            {view === 'test' && (
              <motion.div 
                key="test"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="max-w-xl"
              >
                <span className="label-typography text-brand-red mb-4 block uppercase tracking-widest">Pemeriksaan Simptom</span>
                <h2 className="text-5xl font-black mb-8 leading-[0.9] uppercase italic">Pernah anda<br />alami ini?</h2>
                
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="space-y-4 mb-12"
                >
                  {QUESTIONS.map((q) => (
                    <motion.button
                      variants={itemVariants}
                      key={q.id}
                      onClick={() => toggleAnswer(q.id)}
                      className={`w-full text-left p-6 rounded-2xl border transition-all flex items-center justify-between group active:scale-[0.98] ${
                        answers.has(q.id) 
                          ? 'border-brand-red bg-zinc-900/50' 
                          : 'border-zinc-800 bg-zinc-900 hover:border-zinc-700 hover:bg-zinc-800/50'
                      }`}
                    >
                      <div className="flex-1 pr-4">
                        <p className="text-lg font-bold leading-tight uppercase tracking-tight">{q.text}</p>
                        <p className="text-[10px] label-typography opacity-40 mt-1">{q.category}</p>
                      </div>
                      <div className={`w-8 h-8 rounded-full border-4 flex-shrink-0 transition-all duration-300 ${
                        answers.has(q.id) ? 'bg-brand-red border-white/20' : 'border-zinc-700'
                      }`} />
                    </motion.button>
                  ))}
                </motion.div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => setView('home')}
                    className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-white transition-transform active:scale-90"
                  >
                    <RefreshCw className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={calculateResult}
                    disabled={answers.size === 0}
                    className="flex-1 bg-white text-black p-5 rounded-2xl font-black uppercase text-lg tracking-widest disabled:opacity-20 hover:scale-[1.02] transition-transform active:scale-95 shadow-xl shadow-white/5"
                  >
                    ANALISIS RISIKO SEKARANG
                  </button>
                </div>
              </motion.div>
            )}

            {view === 'computing' && (
              <motion.div 
                key="computing"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.1 }}
                className="max-w-xl h-full flex flex-col items-center justify-center text-center"
              >
                <div className="relative w-32 h-32 mb-8">
                  <motion.div 
                    className="absolute inset-0 border-8 border-zinc-800 rounded-full"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  />
                  <motion.div 
                    className="absolute inset-0 border-8 border-t-brand-red border-r-transparent border-b-transparent border-l-transparent rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  />
                </div>
                <h2 className="text-4xl font-black uppercase italic tracking-tighter mb-4 animate-pulse">Menghitung Risiko...</h2>
                <p className="label-typography opacity-40">Menganalisis Jawapan Mengikut Garis Panduan KPM</p>
              </motion.div>
            )}

            {view === 'result' && (
              <div className="max-w-4xl h-full flex flex-col lg:flex-row gap-12 items-center">
                <motion.div 
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex-1"
                >
                  <span className="label-typography mb-4 block">Hasil Analisis</span>
                  <h2 className="text-6xl md:text-8xl font-black mb-6 uppercase italic leading-[0.8] tracking-tighter">
                    Keputusan<br />Anda.
                  </h2>
                  <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800 flex items-center gap-6">
                    <div className="text-center">
                      <p className="label-typography mb-1">SKOR ANDA</p>
                      <p className="text-6xl font-black">
                        {Array.from(answers).length * 12}<span className="text-2xl">%</span>
                      </p>
                    </div>
                    <div className="h-12 w-px bg-zinc-800" />
                    <p className="text-slate-400 font-bold uppercase text-sm italic">
                      Skor dikira berasaskan berat (weightage) setiap jenis ancaman yang anda pilih.
                    </p>
                  </div>
                </motion.div>
                <div className="w-full lg:w-[420px]">
                  <ResultCard level={riskLevel} onReset={() => setView('home')} />
                </div>
              </div>
            )}

            {view === 'journal' && (
              <motion.div 
                key="journal"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="max-w-3xl"
              >
                <div className="flex items-center justify-between mb-10">
                  <div>
                    <span className="label-typography text-brand-red mb-2 block">Ruang Privasi</span>
                    <h2 className="text-6xl font-black uppercase italic leading-none">Bilik<br />Luahan.</h2>
                  </div>
                   <button onClick={() => setView('home')} className="p-4 bg-zinc-900 rounded-full border border-zinc-800 transition-transform active:scale-90">
                    <X className="w-8 h-8 opacity-40 hover:opacity-100" />
                  </button>
                </div>

                <div className="relative">
                  <textarea
                    placeholder="TAIP DI SINI..."
                    className="w-full h-[400px] p-10 rounded-[40px] bg-zinc-900 border-2 border-zinc-800 focus:border-brand-red outline-none transition-all text-2xl font-bold leading-relaxed placeholder:opacity-10"
                  />
                  <div className="absolute bottom-8 right-8 flex gap-4">
                    <button className="px-8 py-4 bg-zinc-950 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-transform active:scale-95">PADAM</button>
                    <button className="px-8 py-4 bg-brand-red text-black rounded-2xl font-black text-xs uppercase tracking-widest transition-transform active:scale-95">SIMPAN</button>
                  </div>
                </div>

                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="mt-8 flex items-center gap-4 p-6 bg-zinc-900/50 rounded-2xl border border-zinc-800"
                >
                  <EyeOff className="w-10 h-10 text-brand-red" />
                  <div>
                    <p className="font-black text-sm uppercase">Mod Penyamaran Aktif</p>
                    <p className="text-xs font-bold text-slate-500 uppercase">Input anda tidak akan dihantar ke mana-mana database.</p>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Floating Help Anchor */}
      <button 
        className="fixed bottom-10 right-10 w-20 h-20 bg-brand-red text-black rounded-full shadow-[0_0_50px_rgba(239,68,68,0.3)] flex items-center justify-center hover:scale-110 active:scale-95 transition-all group z-50 overflow-hidden"
      >
        <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity" />
        <HelpCircle className="w-10 h-10" />
      </button>

    </div>
  );
}
